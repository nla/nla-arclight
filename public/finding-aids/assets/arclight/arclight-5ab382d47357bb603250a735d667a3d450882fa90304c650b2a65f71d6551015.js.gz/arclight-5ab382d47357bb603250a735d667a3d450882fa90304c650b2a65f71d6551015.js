import Truncate from 'arclight/truncate_controller'
Stimulus.register('arclight-truncate', Truncate)
import Oembed from 'arclight/oembed_controller'
Stimulus.register('arclight-oembed', Oembed);
